package com.stylehair.nerdsolutions.stylehair.classes;

import java.util.List;

public class GetUsuarioFuncionario {
    public List<UsuarioFuncionario> funcionarios;

    public List<UsuarioFuncionario> getFuncionarios() {
        return funcionarios;
    }

    public void setFuncionarios(List<UsuarioFuncionario> funcionarios) {
        this.funcionarios = funcionarios;
    }
}
