package com.stylehair.nerdsolutions.stylehair.classes;

public class IdNovoUsuario {
    private int idUsuario;

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
}
