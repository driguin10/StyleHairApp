package com.stylehair.nerdsolutions.stylehair.Notification.backNotification;

/**
 * Created by Rodrigo on 19/02/2018.
 */

public class Common {
    public static String currenToken ="";
}
