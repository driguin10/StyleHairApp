package com.stylehair.nerdsolutions.stylehair.classes;

/**
 * Created by Rodrigo on 25/01/2018.
 */

public class Usuario {
    public int idUsuario;
    public int idLogin;
    public String linkImagem;
    public String nome;
    public String apelido;
    public String sexo;
    public String dataNascimento;
    public String telefone;
    public  String cep;
    public String endereco;
    public int numero;
    public String bairro;
    public String estado;
    public String cidade;
    public String obs;
    public String topicoNotificacao;
    public String mostrarNotificacao;

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdLogin() {
        return idLogin;
    }

    public void setIdLogin(int idLogin) {
        this.idLogin = idLogin;
    }

    public String getLinkImagem() {
        return linkImagem;
    }

    public void setLinkImagem(String linkImagem) {
        this.linkImagem = linkImagem;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getApelido() {
        return apelido;
    }

    public void setApelido(String apelido) {
        this.apelido = apelido;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }



    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public String getTopicoNotificacao() {
        return topicoNotificacao;
    }

    public void setTopicoNotificacao(String topicoNotificacao) {
        this.topicoNotificacao = topicoNotificacao;
    }

    public String getMostrarNotificacao() {
        return mostrarNotificacao;
    }

    public void setMostrarNotificacao(String mostrarNotificacao) {
        this.mostrarNotificacao = mostrarNotificacao;
    }
}
