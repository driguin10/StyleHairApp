package com.stylehair.nerdsolutions.stylehair.classes;

/**
 * Created by Rodrigo on 18/01/2018.
 */

public class Login {
    private int idLogin;
    private String email;
    private String senha;


    public int getIdLogin() {
        return idLogin;
    }

    public void setIdLogin(int idLogin) {
        this.idLogin = idLogin;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

}
