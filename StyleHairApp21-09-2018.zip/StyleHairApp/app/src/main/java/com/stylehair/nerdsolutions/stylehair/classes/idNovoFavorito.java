package com.stylehair.nerdsolutions.stylehair.classes;

public class idNovoFavorito {
    private int idFavorito;

    public int getIdFavorito() {
        return idFavorito;
    }

    public void setIdFavorito(int idFavorito) {
        this.idFavorito = idFavorito;
    }
}
