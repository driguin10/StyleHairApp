package com.stylehair.nerdsolutions.stylehair.classes;

public class ConfigHorarioSalao {

    private String segE;
    private String segS;
    private String terE;
    private String terS;
    private String quaE;
    private String quaS;
    private String quiE;
    private String quiS;
    private String sexE;
    private String sexS;
    private String sabE;
    private String sabS;
    private String domE;
    private String domS;
    private int agendamento;

    public String getSegE() {
        return segE;
    }

    public void setSegE(String segE) {
        this.segE = segE;
    }

    public String getSegS() {
        return segS;
    }

    public void setSegS(String segS) {
        this.segS = segS;
    }

    public String getTerE() {
        return terE;
    }

    public void setTerE(String terE) {
        this.terE = terE;
    }

    public String getTerS() {
        return terS;
    }

    public void setTerS(String terS) {
        this.terS = terS;
    }

    public String getQuaE() {
        return quaE;
    }

    public void setQuaE(String quaE) {
        this.quaE = quaE;
    }

    public String getQuaS() {
        return quaS;
    }

    public void setQuaS(String quaS) {
        this.quaS = quaS;
    }

    public String getQuiE() {
        return quiE;
    }

    public void setQuiE(String quiE) {
        this.quiE = quiE;
    }

    public String getQuiS() {
        return quiS;
    }

    public void setQuiS(String quiS) {
        this.quiS = quiS;
    }

    public String getSexE() {
        return sexE;
    }

    public void setSexE(String sexE) {
        this.sexE = sexE;
    }

    public String getSexS() {
        return sexS;
    }

    public void setSexS(String sexS) {
        this.sexS = sexS;
    }

    public String getSabE() {
        return sabE;
    }

    public void setSabE(String sabE) {
        this.sabE = sabE;
    }

    public String getSabS() {
        return sabS;
    }

    public void setSabS(String sabS) {
        this.sabS = sabS;
    }

    public String getDomE() {
        return domE;
    }

    public void setDomE(String domE) {
        this.domE = domE;
    }

    public String getDomS() {
        return domS;
    }

    public void setDomS(String domS) {
        this.domS = domS;
    }

    public int getAgendamento() {
        return agendamento;
    }

    public void setAgendamento(int agendamento) {
        this.agendamento = agendamento;
    }
}
