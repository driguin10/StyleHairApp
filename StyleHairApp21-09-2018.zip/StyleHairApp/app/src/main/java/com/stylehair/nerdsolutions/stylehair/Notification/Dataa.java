package com.stylehair.nerdsolutions.stylehair.Notification;

public class Dataa {
    private String salao;
    private String data;

    public Dataa(String salao, String data) {
        this.salao = salao;
        this.data = data;
    }

    public String getSalao() {
        return salao;
    }

    public void setSalao(String salao) {
        this.salao = salao;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
