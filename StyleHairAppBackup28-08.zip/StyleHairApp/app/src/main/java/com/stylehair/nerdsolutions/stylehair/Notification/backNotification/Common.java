package com.stylehair.nerdsolutions.stylehair.Notification.backNotification;

public class Common {
    public static String currenToken ="";
}
