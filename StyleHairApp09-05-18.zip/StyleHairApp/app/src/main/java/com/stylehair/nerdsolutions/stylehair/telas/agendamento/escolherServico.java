package com.stylehair.nerdsolutions.stylehair.telas.agendamento;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.stylehair.nerdsolutions.stylehair.R;

public class escolherServico extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolher_servico);
    }
}
