package com.stylehair.nerdsolutions.stylehair.classes;

public class FeriasFuncionario {
    public String feriasIni;
    public String feriasFim;

    public String getFeriasIni() {
        return feriasIni;
    }

    public void setFeriasIni(String feriasIni) {
        this.feriasIni = feriasIni;
    }

    public String getFeriasFim() {
        return feriasFim;
    }

    public void setFeriasFim(String feriasFim) {
        this.feriasFim = feriasFim;
    }
}
