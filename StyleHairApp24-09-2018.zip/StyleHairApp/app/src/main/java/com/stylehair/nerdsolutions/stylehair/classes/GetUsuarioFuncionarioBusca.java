package com.stylehair.nerdsolutions.stylehair.classes;

import java.util.List;

public class GetUsuarioFuncionarioBusca {
    public List<UsuarioFuncionarioBusca> funcionarios;

    public List<UsuarioFuncionarioBusca> getFuncionarios() {
        return funcionarios;
    }

    public void setFuncionarios(List<UsuarioFuncionarioBusca> funcionarios) {
        this.funcionarios = funcionarios;
    }
}
