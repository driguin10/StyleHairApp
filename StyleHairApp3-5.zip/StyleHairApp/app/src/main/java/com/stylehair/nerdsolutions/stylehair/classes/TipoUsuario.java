package com.stylehair.nerdsolutions.stylehair.classes;



/**
 * Created by Rodrigo on 19/03/2018.
 */

public class TipoUsuario {
    int idUsuario;
    int idFuncionario;
    int idSalao;

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public int getIdSalao() {
        return idSalao;
    }

    public void setIdSalão(int idSalao) {
        this.idSalao = idSalao;
    }
}
